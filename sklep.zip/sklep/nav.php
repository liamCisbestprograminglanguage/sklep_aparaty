<div class="navbar">
    <button id="toggle-btn">///</button>
    <h3 class="navbar-title">Aparaty.pl</h3>
    <div class="search-container">
        <form id="search-form" action="index.php" method="GET">
            <input type="text" name="query" placeholder="Szukaj..." class="search-input" id="search-input">
        </form>
    </div>
</div>

<div id="navbar_bottom" class="side-navbar">
    <ul>
        <li><a href="index.php">Strona Główna</a></li>
        <li><a href="index.php?id=2">Aparaty</a></li>
        <li><a href="index.php?id=3">Obiektywy</a></li>
        <li><a href="index.php?id=4">Producenci</a></li>
        <li><a href="index.php?id=5">Koszyk</a></li>
    </ul>
</div>