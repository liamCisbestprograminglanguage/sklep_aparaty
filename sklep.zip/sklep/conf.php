<?php
    $servername = "localhost";
    $username = "root";
    $password = "d*M2L!opsddih6378";
    $database = "sklep";

    $conn = new mysqli($servername, $username, $password, $database);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
?>
